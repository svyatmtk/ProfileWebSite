#!/bin/bash

str="Машошин Евгений ИСТ-232м"

# create individual text files in different encodings
iconv -f UTF-8 -t CP866 << EOF > 866CP.txt
$(for i in {1..10000}; do echo "$str"; done)
EOF

iconv -f UTF-8 -t WINDOWS-1251 << EOF > WIND1251.txt
$(for i in {1..10000}; do echo "$str"; done)
EOF

iconv -f UTF-8 -t KOI8-R << EOF > KOI8.txt
$(for i in {1..10000}; do echo "$str"; done)
EOF

iconv -f UTF-8 -t UTF-8 << EOF > UTF8.txt
$(for i in {1..10000}; do echo "$str"; done)
EOF

# create a combined file
cat 866CP.txt WIND1251.txt KOI8.txt UTF8.txt > combined.txt

# compress each file using different archiving utilities
for f in 866CP.txt WIND1251.txt KOI8.txt UTF8.txt combined.txt
do
    arj a -r "${f%.*}.arj" "$f"
    gzip -c "$f" > "${f%.*}.gz"
    zip "${f%.*}.zip" "$f"
    tar -czvf "${f%.*}.tar.gz" "$f"
    bzip2 -c "$f" > "${f%.*}.bz2"
done

echo "Done."

