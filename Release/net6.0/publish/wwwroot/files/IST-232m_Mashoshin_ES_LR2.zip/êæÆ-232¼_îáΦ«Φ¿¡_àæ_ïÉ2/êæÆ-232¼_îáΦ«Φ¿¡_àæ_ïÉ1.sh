#!/bin/bash

str="Машошин Евгений ИСТ-232м"

iconv -f UTF-8 -t CP866 << EOF > 866CP.txt
$(for i in {1..100}; do echo "$str"; done)
EOF

iconv -f UTF-8 -t WINDOWS-1251 << EOF > WIND1251.txt
$(for i in {1..100}; do echo "$str"; done)
EOF

iconv -f UTF-8 -t KOI8-R << EOF > KOI8.txt
$(for i in {1..100}; do echo "$str"; done)
EOF

iconv -f UTF-8 -t UTF-8 << EOF > UTF8.txt
$(for i in {1..100}; do echo "$str"; done)
EOF

cat 866CP.txt WIND1251.txt KOI8.txt UTF8.txt > compile.txt

echo "Done."

